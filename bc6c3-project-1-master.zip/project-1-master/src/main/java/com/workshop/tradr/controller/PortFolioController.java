package com.workshop.tradr.controller;
import java.util.*;
import java.sql.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

/**
 * 
 * @author aravind
 *
 */
//@EnableScheduling
//@Component("myBean")
@Controller
public class PortFolioController
{

	private static final Logger logger = LoggerFactory.getLogger(PortFolioController.class);
	private Date date, prv,currentDate;
	private DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
//	@RequestMapping(value = "/getProfile", method = RequestMethod.GET)
//	public String getProfile(final Locale locale, final Model model) throws SQLException
//	{
//		Connection con=null;
//		try {
//		    
//		    Class.forName("com.mysql.jdbc.Driver");
//		    con =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
//		     Statement st=con.createStatement();
//		   ResultSet rs=st.executeQuery("Select * from customer where Customer_id=101");
//		while(rs.next())
//		{
//		  
//         model.addAttribute("cid", rs.getString(1));
//         model.addAttribute("name", rs.getString(2));
//         model.addAttribute("Custlogin", rs.getString(3));
//         model.addAttribute("dob", rs.getString(7));
//         model.addAttribute("gender", rs.getString(8));
//         model.addAttribute("it", rs.getString(9));
//         model.addAttribute("hid", rs.getString(10));
//       
//
//		}
//		
//		
//		} catch (Exception e) {
//		    
//		}
//		con.close();
////		finally { con.close();}
//
//		PortFolioController.logger.info("Logged");
//
//		return "Profile";
//	}

	
//	@RequestMapping(value = "/getmystocks", method = RequestMethod.GET)
//	public String getMyStocks(final Locale locale, final Model model) throws SQLException
//	{Connection con1=null;
//	try {
//	    
//	    Class.forName("com.mysql.jdbc.Driver");
//	    con1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
//	     Statement st=con1.createStatement();
//	   ResultSet rs2=st.executeQuery("select c.CUSTOMER_ID,sp.STOCK_NAME,ch.QUANTITY,sp.STOCK_PRICE,ch.QUANTITY*sp.STOCK_PRICE from customer c,stock_price sp ,customer_holdings ch where ch.CUSTOMER_ID=c.CUSTOMER_ID and ch.STOCK_ID=sp.STOCK_ID ");		
//	   double pa=0;
//	   ArrayList<Stocks> stocks=new ArrayList<Stocks>();
//	   while(rs2.next())
//		 {
//		   Stocks stock = new Stocks();
//		   stock.setCi(rs2.getString(1));
//		   stock.setCp(rs2.getDouble(4));
//		   stock.setQ(rs2.getInt(3));
//		   stock.setSn(rs2.getString(2));
//		   double x = rs2.getDouble(5);
////		   if 
//		   stock.setTot(x);
//		
//		 pa+=rs2.getDouble(5);
//		 stocks.add(stock);
//		 }
//	   model.addAttribute("portfolio",pa);
//	   model.addAttribute("stocks", stocks);
//		
//		} catch (Exception e) {
//		    
//		}
//		con1.close();
////		finally { con1.close();}
//		PortFolioController.logger.info("Logged");
//
//		return "mystocks";
//	}
@RequestMapping(value = "/getProfile", method = RequestMethod.GET)
	
	
	public String getProfile(final Locale locale, final Model model) throws SQLException
	{
		Connection con=null;
		try {
		    
		    Class.forName("com.mysql.jdbc.Driver");
		    con =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
		     Statement st=con.createStatement();
		   ResultSet rs=st.executeQuery("Select * from customer where Customer_id=101");
		while(rs.next())
		{
		  
         model.addAttribute("cid", rs.getString(1));
         model.addAttribute("name", rs.getString(2));
         model.addAttribute("Custlogin", rs.getString(3));
         model.addAttribute("dob", rs.getString(7));
         model.addAttribute("gender", rs.getString(8));
         model.addAttribute("it", rs.getString(9));
         model.addAttribute("hid", rs.getString(10));
       

		}
		
		
		} catch (Exception e) {
		    
		}
		finally { con.close();}

		PortFolioController.logger.info("Logged");

		return "Profile";
	}
@RequestMapping(value = "/getmystocks", method = RequestMethod.GET)
	
	public String getMyStocks(final Locale locale, final Model model) throws SQLException
	{Connection con1=null;
	try {
	    
	    Class.forName("com.mysql.jdbc.Driver");
	    con1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");
	     Statement st=con1.createStatement();
	   ResultSet rs2=st.executeQuery("select c.CUSTOMER_ID,sp.STOCK_NAME,ch.QUANTITY,sp.STOCK_PRICE,ch.QUANTITY*sp.STOCK_PRICE,sp.CHANGE_PERCENT from customer c,stock_price sp ,customer_holdings ch where ch.CUSTOMER_ID=c.CUSTOMER_ID and ch.STOCK_ID=sp.STOCK_ID ");		
	   double pa=0;
	   ArrayList<Stocks> stocks=new ArrayList<Stocks>();
	   while(rs2.next())
		 {
		   Stocks stock = new Stocks();
		   stock.setCi(rs2.getString(1));
		   stock.setCp(rs2.getDouble(4));
		   stock.setQ(rs2.getInt(3));
		   stock.setSn(rs2.getString(2));
		   stock.setChp(rs2.getDouble(6));
		   double x = rs2.getDouble(5);
		   //if
		   stock.setTot(x);
		
		 pa+=rs2.getDouble(5);
		 stocks.add(stock);
		 }
	   model.addAttribute("portfolio",pa);
	   model.addAttribute("stocks", stocks);
		
		} catch (Exception e) {
		    
		}
		finally { con1.close();}
		PortFolioController.logger.info("Logged");

		return "mystocks";
	}
	

	@RequestMapping(value = "/getHshReports", method = RequestMethod.GET)
	public String getHouseholdReports(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "hshreports";
	}

	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getIndReports", method = RequestMethod.GET)
	public String getIndustryReports(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");

		return "indreports";
	}
	
	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	
	
	@RequestMapping(value = "/getStatement", method = RequestMethod.GET)
	public String getStatement(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");
		double cashAtHand , currBondVal = 0 , initBondVal = 0 ,bondProfit;
		String red = new String("#e57373");
		String green = new String("#66bb6a");
		String previous,current;
		date = new Date();
		currentDate = new Date();
		date.setHours(0);
		date.setMinutes(0);
		date.setSeconds(0);
		prv = DateUtils.addDays(date, -1);
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");   
			//	Realized
			Statement stmt=con.createStatement();
			Statement stmt2=con.createStatement();
			// select * from customer_cash where TRANSACTION_DATE < "2017-03-24 00:00:00" and TRANSACTION_DATE > "2017-03-23 00:00:00" order by TRANSACTION_DATE desc
			ResultSet rs=stmt.executeQuery("select * from customer_cash where TRANSACTION_DATE < '" + df.format(date) + "' and TRANSACTION_DATE > '" + df.format(prv) + "' order by TRANSACTION_DATE desc");
			ResultSet rs2=stmt2.executeQuery("select * from customer_cash where TRANSACTION_DATE <= '" + df.format(currentDate) + "' order by TRANSACTION_DATE desc");
			rs.next(); 
			rs2.next();
			previous = rs.getString(5);
			current = rs2.getString(5);
			model.addAttribute("amount", Double.parseDouble(previous));
			model.addAttribute("currentBal",Double.parseDouble(current));
			cashAtHand =  Double.parseDouble(current) - Double.parseDouble(previous);
			model.addAttribute("cashAtHand", cashAtHand);
			//model.addAttribute("cashAtHand", cashAtHand);
			//	Notional
			Statement not_st1 = con.createStatement();
			Statement not_s2 = con.createStatement();
			ResultSet not1, not2; 
			not1 = not_st1.executeQuery("select STOCK_ID,QUANTITY from customer_holdings where CUSTOMER_ID = 101");
			while (not1.next()) {
				not2 = not_s2.executeQuery("select STOCK_PRICE from stock_price where STOCK_ID = " + not1.getString(1));
				not2.next();
				currBondVal += (Double.parseDouble(not2.getString(1)) * Double.parseDouble(not1.getString(2)));
			}
			model.addAttribute("currBondVal",currBondVal);
			
			Statement in1 = con.createStatement();
			Statement in2 = con.createStatement();
			ResultSet res1, res2; 
			res1 = in1.executeQuery("select STOCK_ID,QUANTITY from customer_holdings where CUSTOMER_ID = 101");
			while (res1.next()) {
				res2 = in2.executeQuery("select PREV_CLOSE from stock_price where STOCK_ID = " + res1.getString(1));
				res2.next();
				initBondVal += (Double.parseDouble(res2.getString(1)) * Double.parseDouble(res1.getString(2)));
			}			
			model.addAttribute("initBondVal",initBondVal);
			bondProfit = currBondVal - initBondVal;
			model.addAttribute("bondProfit", bondProfit);
			model.addAttribute("time", currentDate);
			con.close();  
			}catch(Exception e){ System.out.println(e);}
		return "statement";
	}
	
	/**
	 * DATSABASE
	 * 
	 * insert into stock_price values(101,'BSE',30,'2017-03-23 12:11:00','apple',12,20,11.11,14,10.7,10.2);
	 * 
	 * insert into customer_cash values(102, "2017-03-24 05:10:20", "CREDIT", "DEPOSIT" , 12000);
insert into customer_cash values(102, "2017-03-24 06:10:20", "CREDIT", "DEPOSIT" , 200);
insert into customer_cash values(102, "2017-03-24 07:10:20", "CREDIT", "DEPOSIT" , 6000);
insert into customer_cash values(102, "2017-03-24 08:10:20", "CREDIT", "DEPOSIT" , 30);
insert into customer_cash values(102, "2017-03-24 09:10:20", "CREDIT", "DEPOSIT" , 250);
insert into customer_cash values(102, "2017-03-24 10:10:20", "CREDIT", "DEPOSIT" , 12000);
insert into customer_cash values(102, "2017-03-24 15:10:20", "CREDIT", "DEPOSIT" , 5000);
insert into customer_cash values(102, "2017-03-24 20:10:20", "CREDIT", "DEPOSIT" , 12000);
insert into customer_cash values(102, "2017-03-24 22:10:20", "CREDIT", "DEPOSIT" , 12000);
insert into customer_cash values(102, "2017-03-24 23:10:20", "CREDIT", "DEPOSIT" , 12000);
insert into customer_cash values(102, "2017-03-24 23:15:20", "CREDIT", "DEPOSIT" , 500);

	 */

	/**
	 * 
	 * @param locale
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/watchlist2", method = RequestMethod.GET)
	public String getWatchlist2(final Locale locale, final Model model, @RequestParam("thresh") String threshold,@RequestParam("id") String id )
	{
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");   
			Statement stmt=con.createStatement();
			System.out.println("till here ok");
			stmt.executeUpdate("insert into customer_watch_list values(101,"+Integer.parseInt(id)+",NULL,\"0\",\""+threshold+"\",\"9176171642\")");
			//insert into customer_watch_list values(101, 10001, NULL, '0', "34", "91415153");
			//101,"+Integer.parseInt(id)+",NULL,\"0\",\""+threshold+"\",\"9176171642\"
//			CUSTOMER_ID int(11) 
//			STOCK_ID int(11) 
//			EXPIRY_DATE datetime 
//			ALERT_FLAG char(1) 
//			ALERT_MEDIUM varchar(10) 
//			ALERT_CONTACT varchar(25
			
//			ResultSet rs = stmt.executeQuery("select ALERT_MEDIUM from customer_watch_list where STOCK_ID = "+Integer.parseInt(id));
//			rs.next();
//			int present = Integer.parseInt(rs.getString(1));
//			ResultSet rs1 = stmt.executeQuery("select STOCK_PRICE from stock_price where STOCK_ID = "+Integer.parseInt(id));
//			rs1.next();
//			if (Integer.parseInt(rs1.getString(1)) > Integer.parseInt(threshold)) {
//				System.out.println("Put alert");
//			}
			
			con.close();  
		}catch(Exception e){ System.out.println(e);}
		
		
		return "redirect:watchlist";
	}
	@RequestMapping(value = "/watchlist", method = RequestMethod.GET)
	public String getWatchlist(final Locale locale, final Model model)
	{
		PortFolioController.logger.info("Logged");
		String toDisplay ="";
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/tradr","root","");   
			Statement stmt=con.createStatement();
			Statement stmt2=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from stock_master");
			ResultSet rs2;
			while (rs.next()) {
				toDisplay +="<tr>";
				for(int i=2;i<=4;i++)
				
					toDisplay+="<td>"+rs.getString(i)+"</td>";
			
				rs2=stmt2.executeQuery("select STOCK_PRICE from stock_price where STOCK_ID = "+rs.getString(1) );
				rs2.next();
				toDisplay+="<td>$"+rs2.getString(1)+"</td>";
				toDisplay+="<form action=\"watchlist2\" method=\"GET\"> <input type=\"hidden\" value=\""+rs.getString(1)+"\" name=\"id\"> <td><input style=\"width: 70px;\" type=\"text\" name=\"thresh\"></td><td><input type=\"submit\" value=\"Submit\"></td></form>";
				toDisplay +="</tr>";
			}
		//	model.addAttribute("data1",model);
			model.addAttribute("data", toDisplay);
			con.close();  
		}catch(Exception e){ System.out.println(e);}
		return "watchlist";
	}
//	public void alertFn(){
//		try{Class.forName("com.mysql.jdbc.Driver");
//		Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tradr", "root", "");
//		String sql_sbl="Select STOCK_SYMBOL from STOCK_MASTER";
//		java.sql.PreparedStatement sbl=con.prepareStatement(sql_sbl); 
//		ResultSet rs=sbl.executeQuery();
//		while(rs.next())
//		{
//			APIStockDetails apiStockDetails = new APIStockDetails();
//			TradrStock tradrStock = apiStockDetails.getStockDetails(rs.getString(1));
//			
//			DAOImpl daoImpl = new DAOImpl();
//			daoImpl.persistStockDetails(tradrStock);
//		}
//		System.out.println("Auto Data Updation Successfull");
//		}catch (Exception e){
//		System.out.println(e);	
//		}
//		}


	}

